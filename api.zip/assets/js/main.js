(function () {
    console.log("probando");
})();